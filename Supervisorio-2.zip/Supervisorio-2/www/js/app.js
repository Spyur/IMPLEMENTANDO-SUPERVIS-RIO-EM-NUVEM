// Configurações do MQTT
const host = "test.mosquitto.org";
const port = "8081";  // Porta para WebSocket não seguro
const clientId = `mqtt_${Math.random().toString(16).slice(3)}`;
const connectUrl = `wss://${host}:${port}/mqtt`;

// Tópicos para LEDs (Publicação) e Sensores (Subscrição) - Valores padrão
let led1Topic = localStorage.getItem('led1Topic') || "led/1";
let led2Topic = localStorage.getItem('led2Topic') || "led/2";
let led3Topic = localStorage.getItem('led3Topic') || "led/3";
let sensor1Topic = localStorage.getItem('sensor1Topic') || "sensor/1";
let analogSensorTopic = localStorage.getItem('analogSensorTopic') || "sensor/2";
let sensor2Topic = localStorage.getItem('sensor2Topic') || "sensor/3";
let pressureSensorTopic = localStorage.getItem('pressureSensorTopic') || "sensor/pressao";
let cubeColorTopic = localStorage.getItem('cubeColorTopic') || "sensor/cubo";

// Variáveis para controlar o estado dos LEDs
let led1State = false;
let led2State = false;
let led3State = false;

let client;  // Declaração global do objeto client para torná-lo acessível
let scene, camera, renderer, cube;

// Função para alternar o estado do LED e publicar o estado
const toggleLed = (ledState, buttonId, ledTopic) => {
  const newState = !ledState;
  const message = newState ? "true" : "false";
  
  // Verifica se o client está conectado antes de publicar
  if (client && client.connected) {
    client.publish(ledTopic, message);
    console.log(`Enviando mensagem '${message}' para o tópico ${ledTopic}`);
  } else {
    console.error('Cliente MQTT não conectado.');
  }
  
  // Atualiza o texto do botão
  document.getElementById(buttonId).textContent = newState ? `Desligar ${buttonId.replace('toggle-', '').toUpperCase()}` : `Ligar ${buttonId.replace('toggle-', '').toUpperCase()}`;
  
  return newState; // Retorna o novo estado para atualizar a variável
};

// Função para atualizar o gráfico de barra (pressionando o valor da pressão)
let pressureChart;
const updatePressureBar = (pressureValue) => {
  if (pressureChart) {
    pressureChart.data.datasets[0].data[0] = pressureValue;  // Atualiza o valor da pressão no gráfico
    pressureChart.update();  // Atualiza o gráfico visualmente
  }
};

// Função para inicializar o cubo 3D usando Three.js
const initCube = () => {
  // Configura a cena
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);

  document.getElementById('cubeContainer').appendChild(renderer.domElement);

  // Cria o cubo
  const geometry = new THREE.BoxGeometry(2, 2, 2);
  const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
  cube = new THREE.Mesh(geometry, material);
  scene.add(cube);

  camera.position.z = 5;

  // Função de animação
  const animate = () => {
    requestAnimationFrame(animate);
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    renderer.render(scene, camera);
  };
  
  animate();
};

// Função para alterar a cor do cubo com base no MQTT
const changeCubeColor = (color) => {
  switch (color.toLowerCase()) {
    case 'r':
      cube.material.color.set(0xff0000);
      break;
    case 'p':
      cube.material.color.set(0x800080);
      break;
    case 'w':
      cube.material.color.set(0xffffff);
      break;
    case 'b':
      cube.material.color.set(0x000000);
      break;
    case 'g':
      cube.material.color.set(0x00ff00);
      break;
    default:
      console.log(`Cor desconhecida: ${color}`);  
  }
};

// Conectar ao broker MQTT e assinar tópicos dinâmicos
document.addEventListener("DOMContentLoaded", function () {
  console.log("DOM completamente carregado, iniciando conexão...");

  // Conectar ao broker MQTT
  client = mqtt.connect(connectUrl, {
    clientId,
    clean: true,
    connectTimeout: 4000,
    reconnectPeriod: 1000,
  });

  client.on("connect", () => {
    console.log("Conexão estabelecida com o MQTT broker!");

    // Subscreve automaticamente aos tópicos carregados do localStorage
    subscribeToTopics();

    // Adicionar eventos de clique para os botões de controle de LED
    if (document.getElementById("toggle-led1")) {
      document.getElementById("toggle-led1").addEventListener("click", () => {
        led1State = toggleLed(led1State, "toggle-led1", led1Topic);
      });
    }

    if (document.getElementById("toggle-led2")) {
      document.getElementById("toggle-led2").addEventListener("click", () => {
        led2State = toggleLed(led2State, "toggle-led2", led2Topic);
      });
    }

    if (document.getElementById("toggle-led3")) {
      document.getElementById("toggle-led3").addEventListener("click", () => {
        led3State = toggleLed(led3State, "toggle-led3", led3Topic);
      });
    }

    // Inicializar gráfico de barra na página gauge.html
    if (document.getElementById('pressureChart')) {
      let ctx = document.getElementById('pressureChart').getContext('2d');
      pressureChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: [''],  // Label única para a barra de pressão
          datasets: [{
            label: 'Pressão (kPa)',
            data: [0],  // Valor inicial da pressão
            backgroundColor: ['#f64147'],
            borderColor: ['#f64147'],
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
              max: 100,  // Limite máximo de 100 para o gráfico de pressão
              ticks: {
                color: '#ffffff'  // Cor branca para os números no eixo Y
              },
              grid: {
                color: '#ffffff'  // Cor branca para as linhas do gráfico
              }
            },
            x: {
              ticks: {
                color: '#ffffff'  // Cor branca para o label da barra
              },
              grid: {
                color: '#ffffff'  // Cor branca para as linhas verticais
              }
            }
          }
        }
      });
    }

    // Inicializar o cubo se a página do cubo for carregada
    if (document.getElementById('cubeContainer')) {
      initCube();  // Inicializa o cubo 3D
    }
  });

  // Função que lida com as mensagens recebidas e altera o estado dos LEDs ou sensores
  client.on("message", (topic, message) => {
    console.log(`Mensagem recebida no tópico ${topic}: ${message.toString()}`);

    // Verifica se o elemento existe antes de tentar manipular

    // Atualiza o estado dos LEDs e sensores de acordo com o tópico recebido
    if (topic === sensor1Topic) {
      const led1Element = document.getElementById("led1");
      if (led1Element) {
        led1Element.className = (message.toString() === "true") ? "led-on" : "led-off";
      }
    }

    if (topic === sensor2Topic) {
      const led2Element = document.getElementById("led2");
      if (led2Element) {
        led2Element.className = (message.toString() === "true") ? "led-on" : "led-off";
      }
    }

    if (topic === led3Topic) {
      const led3Element = document.getElementById("led3");
      if (led3Element) {
        led3Element.className = (message.toString() === "true") ? "led-on" : "led-off";
      }
    }

    // Atualiza o valor do sensor analógico em tempo real no sensor-read.html
    if (topic === analogSensorTopic) {
      const analogValueElement = document.getElementById("analog-value");
      if (analogValueElement) {
        analogValueElement.textContent = `Valor: ${message.toString()}`;
      }
    }

    // Atualiza o gráfico de barra com o valor da pressão no gauge.html
    if (topic === pressureSensorTopic) {
      const pressureValue = parseFloat(message.toString());
      const pressureValueElement = document.getElementById("pressure-value");
      if (pressureValueElement) {
        pressureValueElement.textContent = `Pressão: ${pressureValue} kPa`;
        updatePressureBar(pressureValue);
      }
    }

    // Atualiza a cor do cubo 3D no cube.html
    if (topic === cubeColorTopic) {
      const cubeElement = document.getElementById('cubeContainer');
      if (cubeElement) {
        changeCubeColor(message.toString());
      }
    }
  });

  // Trata erros de conexão e reconexão
  client.on("error", (err) => {
    console.log("Erro de conexão: ", err);
  });

  client.on("reconnect", () => {
    console.log("Tentando reconectar...");
    subscribeToTopics();  // Garante que os tópicos serão resubscritos após reconexão
  });
});

// Função para resetar os tópicos para os valores padrão
function resetTopics() {
  localStorage.setItem('led1Topic', "led/1");
  localStorage.setItem('led2Topic', "led/2");
  localStorage.setItem('led3Topic', "led/3");
  localStorage.setItem('sensor1Topic', "sensor/1");
  localStorage.setItem('analogSensorTopic', "sensor/2");
  localStorage.setItem('sensor2Topic', "sensor/3");
  localStorage.setItem('pressureSensorTopic', "sensor/pressao");
  localStorage.setItem('cubeColorTopic', "sensor/cubo");
  console.log("Tópicos resetados para os valores padrão.");
}

// Função para carregar tópicos do arquivo TXT
function loadTxtConfig(file) {
  const reader = new FileReader();
  reader.onload = function(e) {
    const content = e.target.result;
    const lines = content.split('\n');
    lines.forEach(line => {
      const [key, value] = line.split('=');
      if (key && value) {
        localStorage.setItem(key, value.trim());
      }
    });
    console.log("Tópicos carregados do arquivo .txt");

    // Atualize as variáveis globais com os novos tópicos
    led1Topic = localStorage.getItem('led1Topic');
    sensor1Topic = localStorage.getItem('sensor1Topic');
    // Atualize as outras variáveis globais também

    // Resubscrever aos novos tópicos
    subscribeToTopics();
  };
  reader.readAsText(file);
}

function subscribeToTopics() {
  // Verifica se o cliente MQTT está conectado antes de tentar se inscrever nos tópicos
  if (client && client.connected) {
    const topics = [
      localStorage.getItem('led1Topic'),
      localStorage.getItem('led2Topic'),
      localStorage.getItem('led3Topic'),
      localStorage.getItem('sensor1Topic'),
      localStorage.getItem('sensor2Topic'),
      localStorage.getItem('analogSensorTopic'),
      localStorage.getItem('pressureSensorTopic'),
      localStorage.getItem('cubeColorTopic')
    ];

    // Filtra apenas os tópicos válidos (não nulos ou indefinidos)
    const validTopics = topics.filter(topic => topic !== null && topic !== undefined);

    if (validTopics.length > 0) {
      // Inscreva-se nos novos tópicos
      validTopics.forEach(topic => {
        client.subscribe(topic, (err) => {
          if (!err) {
            console.log(`Inscrito com sucesso no tópico: ${topic}`);
          } else {
            console.error(`Erro ao se inscrever no tópico: ${topic}`, err);
          }
        });
      });
    } else {
      console.error('Nenhum tópico válido encontrado para se inscrever.');
    }
  } else {
    console.error('Cliente MQTT não está conectado. Tentando reconectar...');
    // Tenta se reconectar e ressubscribir quando o cliente estiver conectado
    client.on('connect', () => {
      subscribeToTopics();
    });
  }
}

// Função para carregar os tópicos salvos ao carregar uma página
function loadStoredTopics() {
  // Carregar os tópicos do localStorage ou usar os valores padrão
  led1Topic = localStorage.getItem('led1Topic') || "led/1";
  led2Topic = localStorage.getItem('led2Topic') || "led/2";
  led3Topic = localStorage.getItem('led3Topic') || "led/3";
  sensor1Topic = localStorage.getItem('sensor1Topic') || "sensor/1";
  analogSensorTopic = localStorage.getItem('analogSensorTopic') || "sensor/2";
  sensor2Topic = localStorage.getItem('sensor2Topic') || "sensor/3";
  pressureSensorTopic = localStorage.getItem('pressureSensorTopic') || "sensor/pressao";
  cubeColorTopic = localStorage.getItem('cubeColorTopic') || "sensor/cubo";

  console.log(`Tópicos carregados: LED - ${led1Topic}, Sensor - ${sensor1Topic}`);
}

// Função para carregar os tópicos quando o app é iniciado
document.addEventListener("DOMContentLoaded", function () {
  loadStoredTopics();  // Isso garante que os tópicos serão carregados corretamente

  const clpSelect = document.getElementById('clpSelect');
  const resetButton = document.getElementById('resetConfig');

  if (clpSelect) {
    clpSelect.addEventListener('change', function(event) {
      setClpTopics(event.target.value);
    });
  }

  if (resetButton) {
    resetButton.addEventListener('click', resetTopics);
  }
});
