using System;
using System.Linq;

public interface ICustomUriMapper
{
	Uri CustomMapUri(Uri uri);
}
