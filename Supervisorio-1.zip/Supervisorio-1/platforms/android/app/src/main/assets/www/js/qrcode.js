function lerQrCode() {
	console.log('lerQrCode');

	// Get QRScanner Status
	QRScanner.getStatus(function (status) {
		console.log(status);
	});

	// Prepare
	var callback = function (err, contents) {
    if (err) {
        console.error(err._message);
        return;
    }

    console.log('The QR Code contains: ' + contents);

    // Sobrescreve os tópicos no localStorage
    const params = contents.split(',');
    params.forEach(param => {
        const [key, value] = param.split('=');
        if (key && value) {
            localStorage.setItem(key.trim(), value.trim());
        }
    });

    // Redireciona para a página inicial após a leitura
    window.location.href = 'index.html';
};



	QRScanner.scan(callback);

	// Show
	QRScanner.show(function (status) {
		console.log(status);
	});
}

function qrCodeVoltar() {
	console.log('voltar');

	// Get QRScanner Status
	QRScanner.getStatus(function (status) {
		console.log(status);
	});

	// Hides
	QRScanner.hide(function (status) {
		console.log(status);
	});

	// Destroy
	QRScanner.destroy(function (status) {
		console.log(status);
	});

    window.location.href = 'index.html';
}
